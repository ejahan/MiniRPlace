import './canvas.js';
